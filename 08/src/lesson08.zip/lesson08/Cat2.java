// 第８講 練習問題8-1 行番号付きのCatコマンドの作成
// https://ksuap.github.io/2022autumn/lesson08/assignments/#1-行番号付きの-cat-コマンドの作成
