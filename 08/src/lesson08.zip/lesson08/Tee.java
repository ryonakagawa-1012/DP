// 第８講 練習問題8-4 Teeコマンドの作成
// https://ksuap.github.io/2022autumn/lesson08/assignments/#4-tee-コマンドの作成
