// 第９講 練習問題9-2 電話帳の作成
// https://ksuap.github.io/2022autumn/lesson09/assignments/#2-電話帳の作成
