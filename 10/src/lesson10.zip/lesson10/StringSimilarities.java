// 第10講 練習問題10-11 2つの文字列間の類似度・距離
// https://ksuap.github.io/2022autumn/lesson10/assignments/#11-２つの文字列間の類似度距離
