// 第10講 練習問題10-09 Gzip による圧縮
// https://ksuap.github.io/2022autumn/lesson10/assignments/#9-gzipによる圧縮
