// 第10講 練習問題10-01 コマンドラインで受け取った文字列が特定の文字列かを確認する 
// https://ksuap.github.io/2022autumn/lesson10/assignments/#1-コマンドラインで受け取った文字列が特定の文字列かを確認する
