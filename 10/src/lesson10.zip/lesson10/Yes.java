// 第10講 練習問題10-03 Yesコマンド: 特定文字列を繰り返す
// https://ksuap.github.io/2022autumn/lesson10/assignments/#3-yesコマンド特定文字列を繰り返す
