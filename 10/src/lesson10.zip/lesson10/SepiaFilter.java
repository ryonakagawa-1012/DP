// 第10講 練習問題10-08 セピア色画像への変換
// https://ksuap.github.io/2022autumn/lesson10/assignments/#8-セピア色画像への変換
