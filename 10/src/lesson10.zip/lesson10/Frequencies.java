// 第10講 練習問題10-06 freqコマンド: 与えられたテキストファイルに現れる単語の頻度を求める
// https://ksuap.github.io/2022autumn/lesson10/assignments/#6-freqコマンド与えられたテキストファイルに現れる単語の頻度を求める
