// 第10講 練習問題10-04 Sortコマンド: ファイルの内容をソートする
// https://ksuap.github.io/2022autumn/lesson10/assignments/#4-sortコマンドファイルの内容をソートする
