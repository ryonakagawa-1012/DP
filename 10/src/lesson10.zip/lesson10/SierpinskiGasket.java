// 第10講 練習問題10-08 シェルピンスキーのギャスケット
// https://ksuap.github.io/2022autumn/lesson10/assignments/#8-シェルピンスキーのギャスケット
