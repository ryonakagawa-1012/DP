// 第07講 画像操作 練習問題7-1 グラデーション2
// https://ksuap.github.io/2022autumn/lesson07/assignments/#1-グラデーション2
