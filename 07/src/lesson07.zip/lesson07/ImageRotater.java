// 第07講 画像操作 練習問題7-4 画像の回転
// https://ksuap.github.io/2022autumn/lesson07/assignments/#4-画像の回転
