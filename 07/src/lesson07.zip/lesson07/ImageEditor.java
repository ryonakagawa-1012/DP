// 第07講 画像操作 練習問題7-5 自由課題
// https://ksuap.github.io/2022autumn/lesson07/assignments/#5-自由課題
