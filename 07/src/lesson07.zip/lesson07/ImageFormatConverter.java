// 第07講 画像操作 練習問題7-2 ファイルフォーマット変換
// https://ksuap.github.io/2022autumn/lesson07/assignments/#2-ファイルフォーマット変換
