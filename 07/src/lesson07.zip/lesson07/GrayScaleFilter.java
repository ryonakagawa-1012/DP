// 第07講 画像操作 練習問題7-3 グレースケール画像への変換
// https://ksuap.github.io/2022autumn/lesson07/assignments/#3-グレースケール画像への変換
